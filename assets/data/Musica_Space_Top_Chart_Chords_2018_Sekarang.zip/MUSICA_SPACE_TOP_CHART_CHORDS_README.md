# Musica Space — Top Chart Chords 2018–Sekarang

Paket ini berisi 55 lagu populer dari 2018 sampai snapshot chart 2026 untuk dipakai sebagai data awal fitur chord di website Musica Space.

## Isi paket

- `musica-space-top-chart-chords.json` — file utama untuk diimpor ke website.
- `MUSICA_SPACE_TOP_CHART_CHORDS.md` — katalog yang mudah dibaca.

## Struktur data utama

```js
{
  id,
  title,
  artist,
  release_year,
  chart_year,
  key,
  mode,
  difficulty,
  core_progression,
  roman_numerals,
  section_patterns,
  tags
}
```

## Contoh import

```js
const response = await fetch('/assets/musica-space-top-chart-chords.json');
const catalog = await response.json();

const song = catalog.songs.find(item => item.id === 'as-it-was-harry-styles');
console.log(song.core_progression);
```

## Catatan penting

Data ini memakai progresi chord inti dan tidak memuat lirik, audio, atau partitur lengkap. Beberapa lagu menggunakan simplified playable progression agar cocok untuk piano chord player dan fitur transpose. Chord asli rekaman dapat memiliki voicing, passing chord, slash chord, atau perubahan section tambahan.

Untuk fitur website, sebaiknya tambahkan field terpisah seperti `audio_url`, `cover_art_url`, `is_favorite`, `recent_played_at`, dan `source_license` dari database aplikasimu—jangan mengubah metadata inti lagu.

Sumber chart dan cross-check harmoni tercantum di bagian `references` pada JSON.
